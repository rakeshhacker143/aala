<?php
require 'vendor/autoload.php';

use Kreait\Firebase\Factory;

try {
    $factory = (new Factory)
        ->withServiceAccount(__DIR__ . '/path-to-your-service-account.json');

    $database = $factory->createDatabase();
    echo "Firebase SDK is installed and working!";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
