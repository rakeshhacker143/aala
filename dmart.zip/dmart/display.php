<?php
require 'vendor/autoload.php';

use Kreait\Firebase\Factory;

$serviceAccountPath = __DIR__ . '/firebase.json';

try {
    // Initialize Firebase with the correct database URL
    $factory = (new Factory)
        ->withServiceAccount($serviceAccountPath)
        ->withDatabaseUri('https://dmart-b066c-default-rtdb.firebaseio.com'); // Replace with your database URL

    $database = $factory->createDatabase();

    // Fetch all orders from Firebase
    $reference = $database->getReference('orders');
    $orders = $reference->getValue();

    // Sort orders by 'created_at' in descending order
    if ($orders) {
        usort($orders, function ($a, $b) {
            return strtotime($b['created_at']) - strtotime($a['created_at']);
        });
    }
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>

<body>
    <h1>Order Details</h1>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Mobile</th>
                <th>City</th>
                <th>State</th>
                <th>Address</th>
                <th>Pincode</th>
                <th>Payment Method</th>
                <th>Amount</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($orders): ?>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= htmlspecialchars($order['name']); ?></td>
                        <td><?= htmlspecialchars($order['mobile']); ?></td>
                        <td><?= htmlspecialchars($order['city']); ?></td>
                        <td><?= htmlspecialchars($order['state']); ?></td>
                        <td><?= htmlspecialchars($order['address']); ?></td>
                        <td><?= htmlspecialchars($order['pin']); ?></td>
                        <td><?= htmlspecialchars($order['payment_method']); ?></td>
                        <td><?= htmlspecialchars($order['amount']); ?></td>
                        <td><?= htmlspecialchars($order['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9">No orders found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>

</html>